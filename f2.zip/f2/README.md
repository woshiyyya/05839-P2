# 05839-P2

```
pip install hydralit
streamlit run app.py
```